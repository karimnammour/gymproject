Set WshShell = CreateObject("WScript.Shell")

' 1. Start the Gym Engine (Server) silently in the background
' Use cmd /c to ensure npm is in the path and execution environment is correct
WshShell.Run "cmd /c npm run dev", 0, false

' 2. Give the engine 5 seconds to warm up and initialize the database
WScript.Sleep 5000

' 3. Open the browser to the local app
WshShell.Run "cmd /c start http://localhost:3000", 0, false

