import { app, BrowserWindow } from 'electron';
import path from 'path';
import { fileURLToPath } from 'url';
import { fork } from 'child_process';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
let serverProcess;

function createWindow() {
  const userDataPath = app.getPath('userData');
  
  // Start the Gym Backend as a separate background process
  const serverPath = path.join(__dirname, 'server.js');
  serverProcess = fork(serverPath, [], {
    env: { 
      ...process.env, 
      CUSTOM_DATA_PATH: userDataPath,
      NODE_ENV: 'production'
    }
  });

  const win = new BrowserWindow({
    width: 1400,
    height: 900,
    title: "Gym Manager Pro",
    icon: path.join(__dirname, 'icon.png'),
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true
    }
  });

  // Attempt to load the page with retries (Express takes a second to boot)
  const loadWithRetry = (url, attempts = 0) => {
    win.loadURL(url).catch(() => {
      if (attempts < 10) {
        console.log(`Failed to reach server, retrying... (${attempts + 1})`);
        setTimeout(() => loadWithRetry(url, attempts + 1), 1000);
      } else {
        win.loadFile(path.join(__dirname, 'dist/index.html'));
      }
    });
  };

  loadWithRetry('http://localhost:3000');
  
  win.setMenuBarVisibility(false);
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// Kill the background server when the app closes
app.on('will-quit', () => {
  if (serverProcess) serverProcess.kill();
});
