@echo off
TITLE GYM MANAGER - Desktop Installer
COLOR 0A
cls

echo ======================================================
echo          GYM MANAGER - DESKTOP INSTALLER
echo ======================================================
echo.

set "TARGET_DIR=%~dp0"
set "SCRIPT_PATH=%TARGET_DIR%RUN_GYM_MANAGER.vbs"
set "ICON_PATH=%TARGET_DIR%icon.png"
set "SHORTCUT_NAME=GYM MANAGER.lnk"
set "DESKTOP_PATH=%USERPROFILE%\Desktop\%SHORTCUT_NAME%"

echo [1/2] Installing dependencies...
call npm install

echo [2/2] Creating Desktop Shortcut...
powershell -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut('%DESKTOP_PATH%');$s.TargetPath='wscript.exe';$s.Arguments='\"%SCRIPT_PATH%\"';$s.WorkingDirectory='%TARGET_DIR%';$s.IconLocation='%ICON_PATH%';$s.Description='Open Gym Manager App';$s.Save()"

echo.
echo SUCCESS! 🏆
echo ------------------------------------------------------
echo 1. Check your DESKTOP.
echo 2. You will see a "GYM MANAGER" icon.
echo 3. Double-click it to start the app (NO black window!)
echo.
echo IMPORTANT: Do not move or delete this folder!
echo ------------------------------------------------------
pause
