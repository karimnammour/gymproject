import React, { useState, useEffect } from 'react';
import { 
  Users, 
  CreditCard, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  UserPlus, 
  LayoutDashboard, 
  History,
  TrendingUp,
  Search,
  Trash2,
  Scale,
  Plus,
  RefreshCcw,
  Sun,
  Moon,
  UserCheck,
  UserMinus,
  Dumbbell
} from 'lucide-react';
import { motion } from 'motion/react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell,
  LineChart,
  Line
} from 'recharts';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

type Tab = 'dashboard' | 'attendance' | 'tracker' | 'members' | 'classes';

interface Member {
  id: string;
  name: string;
  expiry: string;
  type: 'monthly' | 'daily';
  status: 'active' | 'inactive';
  classes?: boolean;
  dob?: string;
  created_at: string;
}

interface Payment {
  id: number;
  member_id: string;
  member_name: string;
  amount: number;
  months: number;
  date: string;
  expiry_date: string;
}

interface AttendanceEntry {
  id: number;
  member_id: string;
  member_name: string;
  timestamp: string;
}

interface WeightLog {
  id: number;
  member_id: string;
  member_name: string;
  weight: number;
  date: string;
}

interface HourlyStat {
  hour: string;
  count: number;
}

interface Stats {
  totalRevenue: number;
  totalTransactions: number;
  monthlyRevenue: number;
  dailyRevenue: number;
}

interface ClassType {
  id: string;
  name: string;
}

interface ClassParticipation {
  id: string;
  member_id: string;
  member_name: string;
  class_id: string;
  class_name: string;
  timestamp: string;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [members, setMembers] = useState<Member[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [expiringSoon, setExpiringSoon] = useState<Member[]>([]);
  const [todayAttendance, setTodayAttendance] = useState<AttendanceEntry[]>([]);
  const [hourlyStats, setHourlyStats] = useState<HourlyStat[]>([]);
  const [weightLogs, setWeightLogs] = useState<WeightLog[]>([]);
  const [stats, setStats] = useState<Stats>({ totalRevenue: 0, totalTransactions: 0, monthlyRevenue: 0, dailyRevenue: 0 });
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    if (typeof window !== 'undefined') {
      return (localStorage.getItem('theme') as 'light' | 'dark') || 'dark';
    }
    return 'dark';
  });

  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'light') {
      root.classList.add('light');
    } else {
      root.classList.remove('light');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);
  
  // Form States
  const [formMode, setFormMode] = useState<'register' | 'renew'>('register');
  const [regName, setRegName] = useState('');
  const [regId, setRegId] = useState(''); // Phone number
  const [regDob, setRegDob] = useState('');
  const [regClasses, setRegClasses] = useState(false);
  const [renewMemberId, setRenewMemberId] = useState('');
  const [regType, setRegType] = useState<'monthly' | 'daily'>('monthly');
  const [regMonths, setRegMonths] = useState(1);
  const [regAmount, setRegAmount] = useState(50);
  const [checkInId, setCheckInId] = useState('');
  
  // Pricing logic
  const [baseRate, setBaseRate] = useState(50); // Default monthly rate

  // When type changes, reset base rate and amount
  useEffect(() => {
    const newRate = regType === 'monthly' ? 50 : 5;
    setBaseRate(newRate);
    setRegAmount(regMonths * newRate);
  }, [regType]);

  // When duration changes, update amount based on current base rate
  const handleDurationChange = (duration: number) => {
    setRegMonths(duration);
    setRegAmount(duration * baseRate);
  };

  // When amount changes manually, update base rate for future slider movements
  const handleAmountChange = (amount: number) => {
    setRegAmount(amount);
    if (regMonths > 0) {
      setBaseRate(amount / regMonths);
    }
  };
  
  // Tracker States
  const [trackerMemberId, setTrackerMemberId] = useState('');
  const [trackerWeight, setTrackerWeight] = useState('');
  const [trackerSearch, setTrackerSearch] = useState('');

  // Classes States
  const [classTypes, setClassTypes] = useState<ClassType[]>([]);
  const [classParticipation, setClassParticipation] = useState<ClassParticipation[]>([]);
  const [newClassName, setNewClassName] = useState('');
  const [participationMemberId, setParticipationMemberId] = useState('');
  const [selectedClassId, setSelectedClassId] = useState('');
  const [classesSearch, setClassesSearch] = useState('');

  // Feedback States
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const fetchDashboardData = async (retryCount = 0) => {
    try {
      const res = await fetch('/api/dashboard');
      
      let data;
      const contentType = res.headers.get("content-type");
      if (contentType && contentType.indexOf("application/json") !== -1) {
        data = await res.json();
      } else {
        const text = await res.text();
        throw new Error(`Server returned non-JSON response: ${text.substring(0, 100)}`);
      }

      if (!res.ok) throw new Error(data?.error || `Server error: ${res.status}`);
      if (data.error) throw new Error(data.error);

      setMembers(data.members);
      setPayments(data.payments);
      setExpiringSoon(data.expiringSoon);
      if (data.stats) setStats(data.stats);
    } catch (err) {
      console.error('Fetch error:', err);
      if (retryCount < 3) {
        setTimeout(() => fetchDashboardData(retryCount + 1), 2000);
      } else {
        showMessage(`❌ Connection failed. Please check your internet or refresh.`, 'error');
      }
    }
  };

  const fetchAttendanceData = async () => {
    try {
      const res = await fetch('/api/attendance');
      
      let data;
      const contentType = res.headers.get("content-type");
      if (contentType && contentType.indexOf("application/json") !== -1) {
        data = await res.json();
      } else {
        return; // Silently fail for background background polls unless critically needed
      }

      if (!res.ok) throw new Error(data?.error || `Error ${res.status}`);
      setTodayAttendance(data.todayEntries);
      setHourlyStats(data.hourlyStats);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchTrackerData = async () => {
    try {
      const res = await fetch('/api/tracker');
      
      let data;
      const contentType = res.headers.get("content-type");
      if (contentType && contentType.indexOf("application/json") !== -1) {
        data = await res.json();
      } else {
        return;
      }

      if (!res.ok) throw new Error(data?.error || `Error ${res.status}`);
      setWeightLogs(data.logs);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchClassesData = async () => {
    try {
      const res = await fetch('/api/classes');
      
      let data;
      const contentType = res.headers.get("content-type");
      if (contentType && contentType.indexOf("application/json") !== -1) {
        data = await res.json();
      } else {
        return;
      }

      if (!res.ok) throw new Error(data?.error || `Error ${res.status}`);
      setClassTypes(data.types);
      setClassParticipation(data.participation);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchDashboardData();
    fetchAttendanceData();
    fetchTrackerData();
    fetchClassesData();

    // Combined Heartbeat and Auto-refresh
    const interval = setInterval(() => {
      fetchDashboardData();
      fetchAttendanceData();
      fetchTrackerData();
      fetchClassesData();
      // Explicit heartbeat for auto-shutdown
      fetch('/api/heartbeat', { method: 'POST' }).catch(() => {});
    }, 10000); 

    // Initial heartbeat
    fetch('/api/heartbeat', { method: 'POST' }).catch(() => {});

    return () => clearInterval(interval);
  }, []);

  const showMessage = (text: string, type: 'success' | 'error') => {
    setMessage({ text, type });
    setTimeout(() => setMessage(null), 5000);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      let res;
      if (formMode === 'renew') {
        res = await fetch('/api/renew', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            memberId: renewMemberId, 
            months: regMonths, 
            amount: regAmount, 
            type: regType 
          }),
        });
      } else {
        res = await fetch('/api/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            id: regId, 
            name: regName, 
            months: regMonths, 
            amount: regAmount, 
            type: regType,
            classes: regType === 'monthly' ? regClasses : undefined,
            dob: regType === 'monthly' ? regDob : undefined
          }),
        });
      }

      let data;
      const contentType = res.headers.get("content-type");
      if (contentType && contentType.indexOf("application/json") !== -1) {
        data = await res.json();
      } else {
        throw new Error(`Server returned non-JSON error (${res.status})`);
      }

      if (!res.ok) throw new Error(data?.error || `Server error: ${res.status}`);
      if (data.error) throw new Error(data.error);
      
      if (formMode === 'renew') {
        showMessage(`✅ Membership renewed until ${new Date(data.expiryStr).toLocaleDateString()}!`, 'success');
        setRenewMemberId('');
      } else {
        showMessage(`✅ Member ${regName} registered with ID: ${data.memberId}!`, 'success');
        setRegName('');
        setRegId('');
        setRegDob('');
        setRegClasses(false);
      }
      
      setRegMonths(1);
      setRegAmount(regType === 'monthly' ? 50 : 5);
      fetchDashboardData();
    } catch (err) {
      showMessage(`❌ Error: ${(err as Error).message}`, 'error');
    }
  };

  const handleWeightSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!trackerMemberId || !trackerWeight) return;
    try {
      const res = await fetch('/api/tracker', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ memberId: trackerMemberId, weight: parseFloat(trackerWeight) }),
      });
      
      let data;
      const contentType = res.headers.get("content-type");
      if (contentType && contentType.indexOf("application/json") !== -1) {
        data = await res.json();
      } else {
        throw new Error(`Server returned invalid response (${res.status})`);
      }

      if (!res.ok) throw new Error(data?.error || `Server error: ${res.status}`);
      if (data.error) throw new Error(data.error);
      
      showMessage(`✅ Weight log recorded successfully!`, 'success');
      setTrackerWeight('');
      fetchTrackerData();
    } catch (err) {
      showMessage(`❌ Error: ${(err as Error).message}`, 'error');
    }
  };

  const handleAddClass = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClassName) return;
    try {
      const res = await fetch('/api/classes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newClassName }),
      });
      if (!res.ok) throw new Error('Failed to add class');
      setNewClassName('');
      fetchClassesData();
      showMessage('✅ New class type added!', 'success');
    } catch (err) {
      showMessage('❌ Error adding class', 'error');
    }
  };

  const handleDeleteClass = async (id: string) => {
    try {
      const res = await fetch(`/api/classes/${id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error('Failed to delete class');
      fetchClassesData();
      showMessage('✅ Class type deleted', 'success');
    } catch (err) {
      showMessage('❌ Error deleting class', 'error');
    }
  };

  const handleClassAttendance = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!participationMemberId || !selectedClassId) return;
    try {
      const res = await fetch('/api/classes/attendance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ memberId: participationMemberId, classId: selectedClassId }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to record attendance');
      
      setParticipationMemberId('');
      fetchClassesData();
      showMessage(`✅ Participation recorded for ${data.memberName}!`, 'success');
    } catch (err) {
      showMessage(`❌ Error: ${(err as Error).message}`, 'error');
    }
  };

  const handleCheckIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!checkInId) return;
    try {
      const res = await fetch('/api/checkin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ memberId: checkInId }),
      });

      let data;
      const contentType = res.headers.get("content-type");
      if (contentType && contentType.indexOf("application/json") !== -1) {
        data = await res.json();
      } else {
        const text = await res.text();
        throw new Error(res.ok ? "Success but invalid response" : `Server error: ${res.status}`);
      }

      if (!res.ok) throw new Error(data?.error || `Error ${res.status}`);
      if (data.error) throw new Error(data.error);
      
      showMessage(`✅ Welcome, ${data.memberName}! Check-in recorded.`, 'success');
      setCheckInId('');
      fetchAttendanceData();
    } catch (err) {
      showMessage(`❌ Error: ${(err as Error).message}`, 'error');
    }
  };

  const exportToCSV = (data: any[], filename: string) => {
    if (data.length === 0) return;
    const headers = Object.keys(data[0]).join(',');
    const rows = data.map(obj => 
      Object.values(obj).map(val => `"${String(val).replace(/"/g, '""')}"`).join(',')
    );
    const csvContent = [headers, ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDeleteMember = async (id: string, name: string) => {
    if (deletingId !== id) {
      setDeletingId(id);
      setTimeout(() => setDeletingId(null), 3000); // Reset after 3 seconds
      return;
    }
    
    try {
      const res = await fetch(`/api/members/${id}`, { method: 'DELETE' });
      
      let data;
      const contentType = res.headers.get("content-type");
      if (contentType && contentType.indexOf("application/json") !== -1) {
        data = await res.json();
      } else {
        throw new Error(`Server returned invalid response (${res.status})`);
      }

      if (!res.ok) throw new Error(data?.error || `Server error: ${res.status}`);
      if (data.error) throw new Error(data.error);
      
      showMessage(`✅ Member ${name} deleted successfully.`, 'success');
      setDeletingId(null);
      fetchDashboardData();
      fetchAttendanceData();
      fetchTrackerData();
    } catch (err) {
      showMessage(`❌ Error: ${(err as Error).message}`, 'error');
    }
  };

  const handleToggleStatus = async (member: Member) => {
    const newStatus = member.status === 'active' ? 'inactive' : 'active';
    try {
      const res = await fetch(`/api/members/${member.id}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      
      let data;
      const contentType = res.headers.get("content-type");
      if (contentType && contentType.indexOf("application/json") !== -1) {
        data = await res.json();
      } else {
        const text = await res.text();
        throw new Error(`Server returned non-JSON response: ${text.substring(0, 100)}`);
      }

      if (!res.ok) throw new Error(data?.error || `Server error: ${res.status}`);
      if (data.error) throw new Error(data.error);
      
      showMessage(`✅ Member ${member.name} marked as ${newStatus}.`, 'success');
      // Force immediate update then fetch
      setMembers(prev => prev.map(m => m.id === member.id ? { ...m, status: newStatus } : m));
      fetchDashboardData();
    } catch (err) {
      console.error('Toggle status error:', err);
      showMessage(`❌ Error: ${(err as Error).message}`, 'error');
    }
  };

  const handleDeleteLog = async (id: number) => {
    try {
      const res = await fetch(`/api/tracker/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      fetchTrackerData();
    } catch (err) {
      console.error(err);
    }
  };

  // Prepare chart data with all 24 hours - memoized to prevent unnecessary chart updates
  const fullHourlyData = React.useMemo(() => Array.from({ length: 24 }, (_, i) => {
    const hourStr = i.toString().padStart(2, '0');
    const existing = hourlyStats.find(s => s.hour === hourStr);
    return { hour: `${hourStr}:00`, count: existing ? existing.count : 0 };
  }), [hourlyStats]);

  const [currentTime, setCurrentTime] = React.useState(new Date());

  React.useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen pb-12 bg-[var(--color-bg-main)] text-[var(--color-text-main)]">
      {/* Header */}
      <header className="bg-[var(--color-bg-card)] border-b border-[var(--color-border-card)] sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center gap-3">
              <div className="bg-emerald-500 p-2 rounded-lg">
                <Users className="text-zinc-950 w-6 h-6" />
              </div>
              <h1 className="text-xl font-bold tracking-tight text-emerald-500">GYM <span className="text-[var(--color-text-muted)]">MANAGER</span></h1>
            </div>
            
            <div className="flex items-center gap-4">
              {/* Date & Time Display */}
              <div className="hidden md:flex flex-col items-end mr-2">
                <div className="flex items-center gap-2 text-emerald-500">
                  <Clock className="w-3 h-3" />
                  <span className="font-mono text-sm font-black">
                    {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
                <span className="text-[10px] font-bold text-emerald-500/70 uppercase tracking-widest leading-none mt-1">
                  {currentTime.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' })}
                </span>
              </div>

              <button
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="p-2 rounded-lg bg-[var(--color-bg-main)] border border-[var(--color-border-card)] text-[var(--color-text-muted)] hover:text-emerald-500 transition-colors"
                title="Toggle Light/Dark Mode"
              >
                {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>

              <nav className="flex items-center gap-1 bg-[var(--color-bg-main)] p-1 rounded-lg border border-[var(--color-border-card)]">
              <button
                onClick={() => window.open('/api/download/excel', '_blank')}
                className="flex items-center gap-2 px-3 py-2 rounded-md text-[var(--color-text-muted)] hover:text-emerald-400 hover:bg-emerald-500/5 transition-all text-xs font-bold mr-2 border-r border-[var(--color-border-card)]"
                title="Download full Excel Database Backup"
              >
                <TrendingUp className="w-3 h-3 rotate-180" />
                Excel DB
              </button>
              <button
                onClick={() => setActiveTab('dashboard')}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-md transition-all text-sm font-medium",
                  activeTab === 'dashboard' 
                    ? "bg-emerald-500 text-zinc-950 shadow-lg shadow-emerald-500/20" 
                    : "text-[var(--color-text-muted)] hover:text-emerald-400 hover:bg-emerald-500/5"
                )}
              >
                <LayoutDashboard className="w-4 h-4" />
                Dashboard
              </button>
              <button
                onClick={() => setActiveTab('attendance')}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-md transition-all text-sm font-medium",
                  activeTab === 'attendance' 
                    ? "bg-emerald-500 text-zinc-950 shadow-lg shadow-emerald-500/20" 
                    : "text-[var(--color-text-muted)] hover:text-emerald-400 hover:bg-emerald-500/5"
                )}
              >
                <Clock className="w-4 h-4" />
                Attendance
              </button>
              <button
                onClick={() => setActiveTab('classes')}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-md transition-all text-sm font-medium",
                  activeTab === 'classes' 
                    ? "bg-emerald-500 text-zinc-950 shadow-lg shadow-emerald-500/20" 
                    : "text-[var(--color-text-muted)] hover:text-emerald-400 hover:bg-emerald-500/5"
                )}
              >
                <Dumbbell className="w-4 h-4" />
                Classes
              </button>
              <button
                onClick={() => setActiveTab('tracker')}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-md transition-all text-sm font-medium",
                  activeTab === 'tracker' 
                    ? "bg-emerald-500 text-zinc-950 shadow-lg shadow-emerald-500/20" 
                    : "text-[var(--color-text-muted)] hover:text-emerald-400 hover:bg-emerald-500/5"
                )}
              >
                <Scale className="w-4 h-4" />
                Tracker
              </button>
            </nav>
          </div>
        </div>
      </div>
    </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
        {/* Global Alerts */}
        {message && (
          <div className={cn(
            "mb-8 p-4 rounded-xl border flex items-center gap-3 animate-in fade-in slide-in-from-top-4 duration-300",
            message.type === 'success' 
              ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" 
              : "bg-red-500/10 border-red-500/20 text-red-400"
          )}>
            {message.type === 'success' ? <CheckCircle2 className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
            <p className="font-medium text-sm">{message.text}</p>
          </div>
        )}

        {activeTab === 'dashboard' && (
          <div className="space-y-8">
            {/* Stats Overview */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-[var(--color-bg-card)] rounded-2xl border border-[var(--color-border-card)] p-6 flex items-center justify-between group hover:border-emerald-500/50 transition-all cursor-default relative overflow-hidden">
                <div className="absolute inset-0 bg-emerald-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="flex flex-col gap-1 z-10">
                  <span className="text-xs font-bold text-[var(--color-text-muted)] uppercase tracking-widest">Total Members</span>
                  <span className="text-2xl font-black text-[var(--color-text-main)]">
                    {members.filter(m => m.status === 'active').length} 
                    <span className="text-xs font-normal text-[var(--color-text-muted)] ml-2">({members.length} total)</span>
                  </span>
                </div>
                <div className="bg-emerald-500/10 p-3 rounded-xl z-10 group-hover:bg-emerald-500/20 transition-colors">
                  <Users className="text-emerald-500 w-6 h-6" />
                </div>
              </div>

              <div className="bg-[var(--color-bg-card)] rounded-2xl border border-[var(--color-border-card)] p-6 flex items-center justify-between group hover:border-emerald-500/50 transition-all cursor-default relative overflow-hidden">
                <div className="absolute inset-0 bg-emerald-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="flex flex-col gap-1 z-10">
                  <span className="text-xs font-bold text-[var(--color-text-muted)] uppercase tracking-widest">Revenue</span>
                  <span className="text-2xl font-black text-emerald-500">${stats.totalRevenue.toLocaleString()}</span>
                </div>
                <div className="bg-emerald-500/10 p-3 rounded-xl z-10 group-hover:bg-emerald-500/20 transition-colors">
                  <CreditCard className="text-emerald-500 w-6 h-6" />
                </div>
                
                {/* Hover Details */}
                <div className="absolute inset-0 bg-[var(--color-bg-card)] flex flex-col justify-center px-6 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-4 group-hover:translate-y-0 z-20">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-[var(--color-text-muted)]">Monthly:</span>
                    <span className="text-emerald-500">${stats.monthlyRevenue.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-xs font-bold mt-2">
                    <span className="text-[var(--color-text-muted)]">Daily:</span>
                    <span className="text-emerald-400">${stats.dailyRevenue.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-[10px] font-bold mt-3 pt-2 border-t border-[var(--color-border-card)]">
                    <span className="text-zinc-600">Transactions:</span>
                    <span className="text-[var(--color-text-muted)]">{stats.totalTransactions}</span>
                  </div>
                </div>
              </div>

              <div className="bg-[var(--color-bg-card)] rounded-2xl border border-[var(--color-border-card)] p-6 flex items-center justify-between group hover:border-red-500/50 transition-all cursor-default relative overflow-hidden">
                <div className="absolute inset-0 bg-red-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="flex flex-col gap-1 z-10">
                  <span className="text-xs font-bold text-[var(--color-text-muted)] uppercase tracking-widest">Alerts</span>
                  <span className="text-2xl font-black text-red-500">{expiringSoon.length}</span>
                </div>
                <div className="bg-red-500/10 p-3 rounded-xl z-10 group-hover:bg-red-500/20 transition-colors">
                  <AlertTriangle className="text-red-500 w-6 h-6" />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              {/* Left Column: Stats & Registration */}
              <div className="lg:col-span-4 space-y-8">
                {/* Alert Box */}
                <div className="bg-[var(--color-bg-card)] rounded-2xl border border-[var(--color-border-card)] overflow-hidden">
                  <div className="p-4 bg-red-500/10 border-b border-red-500/10 flex items-center justify-between">
                    <div className="flex items-center gap-2 text-red-400">
                      <AlertTriangle className="w-4 h-4" />
                      <span className="text-xs font-bold uppercase tracking-wider">Critical Alerts</span>
                    </div>
                    <span className="text-xs font-medium text-red-400 bg-red-500/20 px-2 py-0.5 rounded-full">
                      Expiring Soon
                    </span>
                  </div>
                  <div className="p-6">
                    {expiringSoon.length > 0 ? (
                      <div className="space-y-4">
                        {expiringSoon.map(m => (
                          <div key={m.id} className="flex justify-between items-center bg-[var(--color-bg-main)] p-3 rounded-lg border border-[var(--color-border-card)]">
                            <div>
                              <p className="font-medium text-[var(--color-text-main)]">{m.name}</p>
                              <p className="text-xs text-[var(--color-text-muted)] font-mono">{m.id}</p>
                            </div>
                            <div className="text-right">
                              <p className="text-xs font-bold text-red-400">
                                {new Date(m.expiry).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                              </p>
                              <p className="text-[10px] text-zinc-600 uppercase">Expires</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-4">
                        <p className="text-[var(--color-text-muted)] text-sm">No critical alerts currently.</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Registration & Renewal Form */}
                <div className="bg-[var(--color-bg-card)] rounded-2xl border border-[var(--color-border-card)] p-8">
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-2">
                      {formMode === 'register' ? <UserPlus className="text-emerald-500 w-5 h-5" /> : <RefreshCcw className="text-emerald-500 w-5 h-5" />}
                      <h2 className="text-lg font-bold">{formMode === 'register' ? 'New Membership' : 'Renew Membership'}</h2>
                    </div>
                    <button 
                      onClick={() => setFormMode(formMode === 'register' ? 'renew' : 'register')}
                      className="text-[10px] font-black uppercase text-[var(--color-text-muted)] hover:text-emerald-500 transition-colors border-b border-[var(--color-border-card)] hover:border-emerald-500"
                    >
                      Switch to {formMode === 'register' ? 'Renewal' : 'Registration'}
                    </button>
                  </div>

                  <form onSubmit={handleRegister} className="space-y-6">
                    <div className="flex p-1 bg-[var(--color-bg-main)] rounded-lg border border-[var(--color-border-card)]">
                      <button
                        type="button"
                        onClick={() => setRegType('monthly')}
                        className={cn(
                          "flex-1 py-1.5 text-[10px] font-black uppercase rounded transition-all",
                          regType === 'monthly' ? "bg-emerald-500 text-zinc-950" : "text-[var(--color-text-muted)] hover:text-[var(--color-text-main)]"
                        )}
                      >
                        Monthly
                      </button>
                      <button
                        type="button"
                        onClick={() => setRegType('daily')}
                        className={cn(
                          "flex-1 py-1.5 text-[10px] font-black uppercase rounded transition-all",
                          regType === 'daily' ? "bg-emerald-500 text-zinc-950" : "text-[var(--color-text-muted)] hover:text-[var(--color-text-main)]"
                        )}
                      >
                        Daily
                      </button>
                    </div>

                    {formMode === 'register' ? (
                      <>
                        <div>
                          <label className="block text-xs font-bold text-[var(--color-text-muted)] uppercase tracking-widest mb-2">Member Name</label>
                          <input
                            type="text"
                            required
                            value={regName}
                            onChange={(e) => setRegName(e.target.value)}
                            placeholder="e.g. John Doe"
                            className="w-full bg-[var(--color-bg-main)] border border-[var(--color-border-card)] rounded-xl px-4 py-3 text-[var(--color-text-main)] focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all font-medium"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-[var(--color-text-muted)] uppercase tracking-widest mb-2">
                            {regType === 'monthly' ? 'ID (Phone Number)' : 'ID (Optional for Daily)'}
                          </label>
                          <input
                            type="tel"
                            required={regType === 'monthly'}
                            value={regId}
                            onChange={(e) => setRegId(e.target.value)}
                            placeholder={regType === 'monthly' ? "e.g. 0123456789" : "Leave blank for auto-ID"}
                            className="w-full bg-[var(--color-bg-main)] border border-[var(--color-border-card)] rounded-xl px-4 py-3 text-[var(--color-text-main)] focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all font-mono"
                          />
                        </div>

                        {regType === 'monthly' && (
                          <>
                            <div>
                              <label className="block text-xs font-bold text-[var(--color-text-muted)] uppercase tracking-widest mb-2">Date of Birth</label>
                              <input
                                type="date"
                                value={regDob}
                                onChange={(e) => setRegDob(e.target.value)}
                                className="w-full bg-[var(--color-bg-main)] border border-[var(--color-border-card)] rounded-xl px-4 py-3 text-[var(--color-text-main)] focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all font-mono"
                              />
                            </div>

                            <div className="flex items-center gap-3 bg-[var(--color-bg-main)] border border-[var(--color-border-card)] rounded-xl px-4 py-3">
                              <input
                                type="checkbox"
                                id="regClasses"
                                checked={regClasses}
                                onChange={(e) => setRegClasses(e.target.checked)}
                                className="w-4 h-4 rounded border-[var(--color-border-card)] text-emerald-500 focus:ring-emerald-500 bg-[var(--color-bg-card)]"
                              />
                              <label htmlFor="regClasses" className="text-xs font-bold text-[var(--color-text-muted)] uppercase tracking-widest cursor-pointer select-none">
                                Include Classes
                              </label>
                            </div>
                          </>
                        )}
                      </>
                    ) : (
                      <div>
                        <label className="block text-xs font-bold text-[var(--color-text-muted)] uppercase tracking-widest mb-2">Select Member</label>
                        <select
                          required
                          value={renewMemberId}
                          onChange={(e) => setRenewMemberId(e.target.value)}
                          className="w-full bg-[var(--color-bg-main)] border border-[var(--color-border-card)] rounded-xl px-4 py-3 text-[var(--color-text-main)] focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all font-medium appearance-none"
                        >
                          <option value="">Choose member...</option>
                          {members.map(m => (
                            <option key={m.id} value={m.id}>{m.name} ({m.id})</option>
                          ))}
                        </select>
                      </div>
                    )}
                    
                    <div>
                      <div className="flex justify-between mb-2">
                        <label className="text-xs font-bold text-[var(--color-text-muted)] uppercase tracking-widest">
                          Subscription {regType === 'daily' ? '(Days)' : '(Months)'}
                        </label>
                        <span className="text-xs font-bold text-emerald-500">
                          {regMonths} {regType === 'daily' ? (regMonths === 1 ? 'Day' : 'Days') : (regMonths === 1 ? 'Month' : 'Months')}
                        </span>
                      </div>
                      <input
                        type="range"
                        min="1"
                        max={regType === 'daily' ? 31 : 12}
                        step="1"
                        value={regMonths}
                        onChange={(e) => handleDurationChange(parseInt(e.target.value))}
                        className="w-full h-2 bg-[var(--color-border-card)] rounded-lg appearance-none cursor-pointer accent-emerald-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[var(--color-text-muted)] uppercase tracking-widest mb-2">Amount Paid ($)</label>
                      <div className="relative">
                        <CreditCard className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                        <input
                          type="number"
                          required
                          value={regAmount}
                          onChange={(e) => handleAmountChange(parseFloat(e.target.value))}
                          className="w-full bg-[var(--color-bg-main)] border border-[var(--color-border-card)] rounded-xl pl-12 pr-4 py-3 text-[var(--color-text-main)] focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all font-mono"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-emerald-500 hover:bg-emerald-600 text-zinc-950 font-bold py-4 rounded-xl transition-all active:scale-[0.98] flex items-center justify-center gap-2"
                    >
                      {formMode === 'register' ? <CheckCircle2 className="w-5 h-5" /> : <RefreshCcw className="w-5 h-5" />}
                      {formMode === 'register' ? 'Complete Registration' : 'Confirm Renewal'}
                    </button>
                  </form>
                </div>
              </div>

              {/* Right Column: Payment History */}
              <div className="lg:col-span-8">
                <div className="bg-[var(--color-bg-card)] rounded-2xl border border-[var(--color-border-card)] overflow-hidden">
                  <div className="p-6 border-b border-[var(--color-border-card)] flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <History className="text-emerald-500 w-5 h-5" />
                      <h2 className="font-bold text-lg text-[var(--color-text-main)]">Recent Transactions</h2>
                    </div>
                    <div className="bg-[var(--color-bg-main)] text-emerald-500 text-[10px] font-black uppercase px-2 py-1 rounded border border-emerald-500/20">
                      Live History
                    </div>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-[var(--color-bg-main)]">
                          <th className="px-6 py-4 text-[10px] font-black uppercase text-[var(--color-text-muted)] tracking-widest">Date</th>
                          <th className="px-6 py-4 text-[10px] font-black uppercase text-[var(--color-text-muted)] tracking-widest">ID</th>
                          <th className="px-6 py-4 text-[10px] font-black uppercase text-[var(--color-text-muted)] tracking-widest">Member</th>
                          <th className="px-6 py-4 text-[10px] font-black uppercase text-[var(--color-text-muted)] tracking-widest">Duration</th>
                          <th className="px-6 py-4 text-[10px] font-black uppercase text-[var(--color-text-muted)] tracking-widest">Amount</th>
                          <th className="px-6 py-4 text-[10px] font-black uppercase text-[var(--color-text-muted)] tracking-widest">Expiry Date</th>
                          <th className="px-6 py-4 text-[10px] font-black uppercase text-[var(--color-text-muted)] tracking-widest text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[var(--color-border-card)]">
                        {payments.length === 0 ? (
                          <tr>
                            <td colSpan={7} className="px-6 py-12 text-center text-[var(--color-text-muted)] text-sm">No transactions recorded yet.</td>
                          </tr>
                        ) : (
                          payments.map(p => (
                            <tr key={p.id} className="hover:bg-[var(--color-bg-main)] transition-colors">
                              <td className="px-6 py-4">
                                <span className="text-xs text-[var(--color-text-muted)] font-mono">{new Date(p.date).toLocaleDateString()}</span>
                              </td>
                              <td className="px-6 py-4 font-mono text-[var(--color-text-muted)] text-xs">{p.member_id}</td>
                              <td className="px-6 py-4">
                                <div className="flex flex-col">
                                  <span className="font-bold text-[var(--color-text-main)] text-sm">{p.member_name || 'Archived Member'}</span>
                                  {members.find(m => m.id === p.member_id)?.status === 'inactive' && (
                                    <span className="text-[9px] font-black uppercase text-red-500">Inactive</span>
                                  )}
                                </div>
                              </td>
                              <td className="px-6 py-4">
                                <span className="text-xs bg-[var(--color-bg-main)] px-2 py-1 rounded border border-[var(--color-border-card)] text-[var(--color-text-muted)]">
                                  {p.months < 1 ? `${Math.round(p.months * 1000)}d` : `${p.months}m`}
                                </span>
                              </td>
                              <td className="px-6 py-4 font-mono font-bold text-emerald-500 text-sm">${p.amount}</td>
                              <td className="px-6 py-4 text-xs font-bold text-zinc-300">
                                {p.expiry_date ? new Date(p.expiry_date).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' }) : '-'}
                              </td>
                              <td className="px-6 py-4 text-right">
                                <div className="flex items-center justify-end gap-3">
                                  <span className="text-[10px] font-black uppercase px-2 py-1 rounded bg-emerald-500/10 text-emerald-500 border border-emerald-500/20">
                                    Paid ✅
                                  </span>
                                  <button 
                                    onClick={() => {
                                      const member = members.find(m => m.id === p.member_id);
                                      if (member) handleToggleStatus(member);
                                    }}
                                    className={cn(
                                      "p-1.5 rounded-md transition-all",
                                      members.find(m => m.id === p.member_id)?.status === 'inactive'
                                        ? "text-emerald-500 hover:bg-emerald-500/10"
                                        : "text-zinc-500 hover:text-red-400 hover:bg-red-500/10"
                                    )}
                                    title={members.find(m => m.id === p.member_id)?.status === 'inactive' ? "Mark Active" : "Mark Inactive"}
                                  >
                                    {members.find(m => m.id === p.member_id)?.status === 'inactive' ? <UserCheck className="w-4 h-4" /> : <UserMinus className="w-4 h-4" />}
                                  </button>
                                  <button 
                                    onClick={() => handleDeleteMember(p.member_id, p.member_name)}
                                    className={cn(
                                      "p-1.5 rounded-md transition-all flex items-center gap-2 text-xs font-bold",
                                      deletingId === p.member_id 
                                        ? "bg-red-500 text-white animate-pulse px-3" 
                                        : "text-zinc-600 hover:text-red-500 hover:bg-red-500/10"
                                    )}
                                    title={deletingId === p.member_id ? "Confirm Delete" : "Delete Member"}
                                  >
                                    {deletingId === p.member_id ? 'CONFIRM?' : <Trash2 className="w-4 h-4" />}
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'classes' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-8 pb-20"
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h2 className="text-3xl font-black text-[var(--color-text-main)] tracking-tighter uppercase italic">Gym Classes Management</h2>
                <p className="text-[var(--color-text-muted)] font-mono text-xs mt-1">Manage class types and record daily participation</p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              {/* Left Side: Attendance Logging */}
              <div className="lg:col-span-4 space-y-8">
                <div className="bg-[var(--color-bg-card)] border border-[var(--color-border-card)] rounded-3xl p-8 shadow-xl">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="p-2 bg-emerald-500/10 rounded-xl text-emerald-500">
                      <Clock className="w-5 h-5" />
                    </div>
                    <h3 className="text-xl font-bold">Record Participation</h3>
                  </div>

                  <form onSubmit={handleClassAttendance} className="space-y-6">
                    <div>
                      <label className="block text-xs font-bold text-[var(--color-text-muted)] uppercase tracking-widest mb-2">Member ID or Name</label>
                      <input
                        type="text"
                        required
                        value={participationMemberId}
                        onChange={(e) => setParticipationMemberId(e.target.value)}
                        placeholder="Search member..."
                        className="w-full bg-[var(--color-bg-main)] border border-[var(--color-border-card)] rounded-xl px-4 py-3 text-[var(--color-text-main)] focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[var(--color-text-muted)] uppercase tracking-widest mb-2">Select Class</label>
                      <select
                        required
                        value={selectedClassId}
                        onChange={(e) => setSelectedClassId(e.target.value)}
                        className="w-full bg-[var(--color-bg-main)] border border-[var(--color-border-card)] rounded-xl px-4 py-3 text-[var(--color-text-main)] focus:outline-none focus:ring-2 focus:ring-emerald-500/50 appearance-none"
                      >
                        <option value="">Choose a class...</option>
                        {classTypes.map(c => (
                          <option key={c.id} value={c.id}>{c.name}</option>
                        ))}
                      </select>
                    </div>

                    <button
                      type="submit"
                      disabled={!participationMemberId || !selectedClassId}
                      className="w-full bg-emerald-500 text-zinc-950 font-black uppercase tracking-widest py-4 rounded-xl hover:bg-emerald-400 transition-all disabled:opacity-50 disabled:grayscale"
                    >
                      Log Participation
                    </button>
                  </form>
                </div>

                <div className="bg-[var(--color-bg-card)] border border-[var(--color-border-card)] rounded-3xl p-8 shadow-xl">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="p-2 bg-emerald-500/10 rounded-xl text-emerald-500">
                      <Plus className="w-5 h-5" />
                    </div>
                    <h3 className="text-xl font-bold">Manage Class Types</h3>
                  </div>

                  <form onSubmit={handleAddClass} className="flex gap-2 mb-6">
                    <input
                      type="text"
                      required
                      value={newClassName}
                      onChange={(e) => setNewClassName(e.target.value)}
                      placeholder="e.g. Crossfit"
                      className="flex-1 bg-[var(--color-bg-main)] border border-[var(--color-border-card)] rounded-xl px-4 py-2 text-sm text-[var(--color-text-main)] focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                    />
                    <button
                      type="submit"
                      className="bg-emerald-500 text-zinc-950 font-bold px-4 rounded-xl hover:bg-emerald-400 transition-all"
                    >
                      Add
                    </button>
                  </form>

                  <div className="space-y-2">
                    {classTypes.map(c => (
                      <div key={c.id} className="flex items-center justify-between bg-[var(--color-bg-main)] p-3 rounded-xl border border-[var(--color-border-card)] group">
                        <span className="text-sm font-bold uppercase tracking-tight">{c.name}</span>
                        <button
                          onClick={() => handleDeleteClass(c.id)}
                          className="text-red-500 opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-red-500/10 rounded"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right Side: Logs & Enrollment View */}
              <div className="lg:col-span-8 space-y-8">
                <div className="bg-[var(--color-bg-card)] border border-[var(--color-border-card)] rounded-3xl overflow-hidden shadow-xl">
                  <div className="px-8 py-6 border-b border-[var(--color-border-card)] bg-emerald-500/5 flex items-center justify-between">
                    <div>
                      <h3 className="text-xl font-bold">Today's Class Participation</h3>
                      <p className="text-[var(--color-text-muted)] text-xs font-mono uppercase mt-1">Live Feed</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Search className="w-4 h-4 text-[var(--color-text-muted)]" />
                      <input
                        type="text"
                        placeholder="Filter logs..."
                        value={classesSearch}
                        onChange={(e) => setClassesSearch(e.target.value)}
                        className="bg-[var(--color-bg-main)] border border-[var(--color-border-card)] rounded-full px-4 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500"
                      />
                    </div>
                  </div>
                  
                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead>
                        <tr className="border-b border-[var(--color-border-card)] bg-[var(--color-bg-main)]/50">
                          <th className="px-8 py-4 text-[10px] font-black uppercase text-[var(--color-text-muted)]">Time</th>
                          <th className="px-8 py-4 text-[10px] font-black uppercase text-[var(--color-text-muted)]">Member</th>
                          <th className="px-8 py-4 text-[10px] font-black uppercase text-[var(--color-text-muted)]">Class</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[var(--color-border-card)]">
                        {classParticipation.length > 0 ? (
                          classParticipation
                            .filter(p => !classesSearch || p.member_name.toLowerCase().includes(classesSearch.toLowerCase()) || p.class_name.toLowerCase().includes(classesSearch.toLowerCase()))
                            .map((p) => (
                              <tr key={p.id} className="hover:bg-emerald-500/5 transition-colors">
                                <td className="px-8 py-4 font-mono text-xs text-emerald-500">
                                  {new Date(p.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                                </td>
                                <td className="px-8 py-4">
                                  <p className="font-bold text-sm">{p.member_name}</p>
                                  <p className="text-[10px] text-[var(--color-text-muted)] font-mono uppercase">{p.member_id}</p>
                                </td>
                                <td className="px-8 py-4">
                                  <span className="bg-emerald-500/10 text-emerald-500 text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest border border-emerald-500/20">
                                    {p.class_name}
                                  </span>
                                </td>
                              </tr>
                            ))
                        ) : (
                          <tr>
                            <td colSpan={3} className="px-8 py-12 text-center text-[var(--color-text-muted)] italic text-sm">
                              No class participation recorded today yet.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="bg-[var(--color-bg-card)] border border-[var(--color-border-card)] rounded-3xl p-8 shadow-xl">
                  <h3 className="text-xl font-bold mb-6 italic uppercase tracking-tighter">Premium Enrollment</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {members.filter(m => m.classes && m.status !== 'inactive').map((member) => (
                      <div key={member.id} className="bg-[var(--color-bg-main)] border border-[var(--color-border-card)] rounded-2xl p-4 flex items-center justify-between hover:border-emerald-500/30 transition-all group">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-500 group-hover:scale-110 transition-transform">
                            <Dumbbell className="w-5 h-5" />
                          </div>
                          <div>
                            <p className="font-bold text-sm leading-tight">{member.name}</p>
                            <p className="text-[10px] text-[var(--color-text-muted)] font-mono">ENROLLED</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-[10px] font-bold text-emerald-500 uppercase">Status</p>
                          <p className="text-[10px] text-[var(--color-text-muted)] font-mono uppercase">
                            Exp: {new Date(member.expiry).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                          </p>
                        </div>
                      </div>
                    ))}
                    {members.filter(m => m.classes && m.status !== 'inactive').length === 0 && (
                      <div className="col-span-full py-8 text-center border-2 border-dashed border-[var(--color-border-card)] rounded-2xl">
                         <p className="text-[var(--color-text-muted)] text-sm italic">No members currently have class access enabled.</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'tracker' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-in fade-in duration-300">
            {/* Left Column: Log Entry */}
            <div className="lg:col-span-4 space-y-8">
              <div className="bg-[var(--color-bg-card)] rounded-2xl border border-[var(--color-border-card)] p-8 h-fit">
                <div className="flex items-center gap-2 mb-6">
                  <Scale className="text-emerald-500 w-5 h-5" />
                  <h2 className="text-lg font-bold">Progress Log</h2>
                </div>
                <form onSubmit={handleWeightSubmit} className="space-y-6">
                  <div>
                    <label className="block text-xs font-bold text-[var(--color-text-muted)] uppercase tracking-widest mb-2">Select Member</label>
                    <select
                      required
                      value={trackerMemberId}
                      onChange={(e) => setTrackerMemberId(e.target.value)}
                      className="w-full bg-[var(--color-bg-main)] border border-[var(--color-border-card)] rounded-xl px-4 py-3 text-[var(--color-text-main)] focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all font-medium appearance-none"
                    >
                      <option value="">Member Name...</option>
                      {members.map(m => (
                        <option key={m.id} value={m.id}>{m.name} ({m.id})</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-[var(--color-text-muted)] uppercase tracking-widest mb-2">Weight (KG)</label>
                    <input
                      type="number"
                      step="0.1"
                      required
                      placeholder="Current weight..."
                      value={trackerWeight}
                      onChange={(e) => setTrackerWeight(e.target.value)}
                      className="w-full bg-[var(--color-bg-main)] border border-[var(--color-border-card)] rounded-xl px-4 py-3 text-[var(--color-text-main)] focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all font-mono"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-emerald-500 hover:bg-emerald-600 text-zinc-950 font-black py-4 rounded-xl transition-all shadow-lg shadow-emerald-500/20 active:scale-[0.98] flex items-center justify-center gap-2"
                  >
                    <Plus className="w-5 h-5" />
                    LOG ENTRY
                  </button>
                </form>
              </div>

              {/* Progress Chart */}
              {trackerMemberId && weightLogs.filter(l => l.member_id === trackerMemberId).length > 1 && (
                <div className="bg-[var(--color-bg-card)] rounded-2xl border border-[var(--color-border-card)] p-6">
                  <h2 className="text-xs font-black uppercase tracking-widest text-[var(--color-text-muted)] mb-6 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-emerald-500" />
                    Weight Journey
                  </h2>
                  <div className="h-48 w-full min-h-[192px]">
                    <ResponsiveContainer width="100%" height="100%" minHeight={192}>
                      <LineChart data={[...weightLogs.filter(l => l.member_id === trackerMemberId)].reverse()}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--color-border-card)" />
                        <XAxis dataKey="date" hide />
                        <YAxis hide domain={['dataMin - 5', 'dataMax + 5']} />
                        <Tooltip
                          contentStyle={{ backgroundColor: 'var(--color-bg-card)', border: '1px solid var(--color-border-card)', borderRadius: '8px' }}
                          labelStyle={{ color: 'var(--color-text-muted)', fontSize: '10px' }}
                          itemStyle={{ color: '#10b981', fontSize: '12px' }}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="weight" 
                          stroke="#10b981" 
                          strokeWidth={2} 
                          dot={{ fill: '#10b981', r: 4 }} 
                          activeDot={{ r: 6, stroke: '#10b981', strokeWidth: 4, fill: 'var(--color-bg-card)' }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              )}
            </div>

            {/* Logs Table */}
            <div className="lg:col-span-8">
              <div className="bg-[var(--color-bg-card)] rounded-2xl border border-[var(--color-border-card)] overflow-hidden">
                <div className="p-6 border-b border-[var(--color-border-card)] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-2">
                    <Scale className="text-emerald-500 w-5 h-5" />
                    <h2 className="font-bold text-lg text-[var(--color-text-main)]">Historical Logs</h2>
                  </div>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3 h-3 text-[var(--color-text-muted)]" />
                    <input
                      type="text"
                      placeholder="Filter by name..."
                      value={trackerSearch}
                      onChange={(e) => setTrackerSearch(e.target.value)}
                      className="bg-[var(--color-bg-main)] border border-[var(--color-border-card)] rounded-lg pl-9 pr-4 py-2 text-xs text-[var(--color-text-main)] focus:outline-none focus:ring-1 focus:ring-emerald-500/50 w-full sm:w-64 transition-all"
                    />
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-[var(--color-bg-main)]">
                        <th className="px-6 py-4 text-[10px] font-black uppercase text-[var(--color-text-muted)] tracking-widest">Date</th>
                        <th className="px-6 py-4 text-[10px] font-black uppercase text-[var(--color-text-muted)] tracking-widest">Member</th>
                        <th className="px-6 py-4 text-[10px] font-black uppercase text-[var(--color-text-muted)] tracking-widest">Weight</th>
                        <th className="px-6 py-4 text-[10px] font-black uppercase text-[var(--color-text-muted)] tracking-widest text-right">Delete</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[var(--color-border-card)]">
                      {weightLogs.filter(log => log.member_name.toLowerCase().includes(trackerSearch.toLowerCase())).length === 0 ? (
                        <tr>
                          <td colSpan={4} className="px-6 py-12 text-center text-[var(--color-text-muted)] text-sm">No records found.</td>
                        </tr>
                      ) : (
                        weightLogs
                          .filter(log => log.member_name.toLowerCase().includes(trackerSearch.toLowerCase()))
                          .map(log => (
                          <tr key={log.id} className="hover:bg-[var(--color-bg-main)] transition-colors">
                            <td className="px-6 py-4 text-xs font-mono text-[var(--color-text-muted)]">
                              {new Date(log.date).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}
                            </td>
                            <td className="px-6 py-4 font-bold text-[var(--color-text-main)] text-sm">{log.member_name}</td>
                            <td className="px-6 py-4 font-black text-emerald-500">{log.weight} KG</td>
                            <td className="px-6 py-4 text-right">
                              <button
                                onClick={() => handleDeleteLog(log.id)}
                                className="p-2 text-[var(--color-text-muted)] hover:text-red-500 hover:bg-red-500/10 rounded-lg transition-all"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'attendance' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Check-in Section */}
            <div className="lg:col-span-4 space-y-8">
              <div className="bg-[var(--color-bg-card)] rounded-2xl border border-[var(--color-border-card)] p-8 h-fit">
                <div className="flex items-center gap-2 mb-6">
                  <LayoutDashboard className="text-emerald-500 w-5 h-5" />
                  <h2 className="text-lg font-bold">Secure Gate</h2>
                </div>
                <form onSubmit={handleCheckIn} className="space-y-6">
                  <div>
                    <label className="block text-xs font-bold text-[var(--color-text-muted)] uppercase tracking-widest mb-2">Member ID or Name</label>
                    <div className="relative">
                      <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                      <input
                        type="text"
                        placeholder="Phone or Name..."
                        value={checkInId}
                        onChange={(e) => setCheckInId(e.target.value)}
                        className="w-full bg-[var(--color-bg-main)] border border-[var(--color-border-card)] rounded-xl pl-12 pr-4 py-4 text-[var(--color-text-main)] text-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all font-mono"
                      />
                    </div>
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-emerald-500 hover:bg-emerald-600 text-zinc-950 font-black py-4 rounded-xl transition-all shadow-lg shadow-emerald-500/20 hover:shadow-emerald-500/40"
                  >
                    IDENTIFY & CHECK-IN
                  </button>
                </form>
              </div>

              {/* Peak Hours Chart */}
              <div className="bg-[var(--color-bg-card)] rounded-2xl border border-[var(--color-border-card)] p-6">
                <div className="flex items-center gap-2 mb-6">
                  <TrendingUp className="text-emerald-500 w-4 h-4" />
                  <h2 className="text-xs font-black uppercase tracking-widest text-[var(--color-text-muted)]">Peak Hours Analytics</h2>
                </div>
                <div className="h-64 w-full min-h-[256px]">
                  <ResponsiveContainer width="100%" height="100%" minHeight={256}>
                    <BarChart data={fullHourlyData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--color-border-card)" />
                      <XAxis 
                        dataKey="hour" 
                        stroke="var(--color-text-muted)" 
                        fontSize={10} 
                        tickLine={false} 
                        axisLine={false}
                        interval={3}
                      />
                      <YAxis hide />
                      <Tooltip 
                        contentStyle={{ backgroundColor: 'var(--color-bg-card)', border: '1px solid var(--color-border-card)', borderRadius: '8px' }}
                        itemStyle={{ color: '#10b981', fontSize: '12px' }}
                        labelStyle={{ color: 'var(--color-text-muted)', fontSize: '10px', marginBottom: '4px' }}
                        cursor={{ fill: 'rgba(16, 185, 129, 0.05)' }}
                      />
                      <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                        {fullHourlyData.map((entry, index) => (
                          <Cell 
                            key={`cell-${index}`} 
                            fill={entry.count > 0 ? '#10b981' : '#27272a'} 
                            fillOpacity={entry.count > 0 ? 0.8 : 0.3}
                          />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            {/* Attendance List */}
            <div className="lg:col-span-8">
              <div className="bg-[var(--color-bg-card)] rounded-2xl border border-[var(--color-border-card)] overflow-hidden">
                <div className="p-6 border-b border-[var(--color-border-card)] flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="text-emerald-500 w-5 h-5" />
                    <h2 className="font-bold text-lg text-[var(--color-text-main)]">Daily Entry Log</h2>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
                    <span className="text-[10px] font-bold text-[var(--color-text-muted)] uppercase tracking-widest">
                      {new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' })}
                    </span>
                  </div>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-[var(--color-bg-main)]">
                          <th className="px-6 py-4 text-[10px] font-black uppercase text-[var(--color-text-muted)] tracking-widest">ID</th>
                          <th className="px-6 py-4 text-[10px] font-black uppercase text-[var(--color-text-muted)] tracking-widest">Member Name</th>
                          <th className="px-6 py-4 text-[10px] font-black uppercase text-[var(--color-text-muted)] tracking-widest">Check-in Time</th>
                          <th className="px-6 py-4 text-[10px] font-black uppercase text-[var(--color-text-muted)] tracking-widest text-right">Signal</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[var(--color-border-card)]">
                        {todayAttendance.length === 0 ? (
                          <tr>
                            <td colSpan={4} className="px-6 py-12 text-center text-[var(--color-text-muted)] text-sm italic">No entries logged today.</td>
                          </tr>
                        ) : (
                          todayAttendance.map(entry => (
                            <tr key={entry.id} className="hover:bg-[var(--color-bg-main)] transition-colors">
                              <td className="px-6 py-4 font-mono text-[var(--color-text-muted)] text-xs">{entry.member_id}</td>
                              <td className="px-6 py-4 font-bold text-[var(--color-text-main)] text-sm">{entry.member_name}</td>
                              <td className="px-6 py-4">
                                <span className="text-emerald-500 font-mono text-xs">
                                  {new Date(entry.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                </span>
                              </td>
                              <td className="px-6 py-4 text-right">
                                <span className="inline-block px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-500 text-[10px] font-bold">
                                  AUTHORIZED ✅
                                </span>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
