import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import * as xlsx from 'xlsx';
import fs from 'fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// --- Excel Database System ---
interface DBState {
  members: any[];
  payments: any[];
  attendance: any[];
  weight_tracker: any[];
  class_types: any[];
  class_participation: any[];
}

let db: DBState = {
  members: [],
  payments: [],
  attendance: [],
  weight_tracker: [],
  class_types: [
    { id: '1', name: 'Kickboxing' },
    { id: '2', name: 'Yoga' },
    { id: '3', name: 'HIIT' },
    { id: '4', name: 'BodyBuilding' },
    { id: '5', name: 'Zumba' }
  ],
  class_participation: []
};

// --- Better Path Handling for Electron ---
const isProduction = process.env.NODE_ENV === 'production';
const isElectron = !!process.versions.electron || !!process.env.CUSTOM_DATA_PATH;

let EXCEL_PATH: string;

if (process.env.CUSTOM_DATA_PATH) {
  EXCEL_PATH = path.join(process.env.CUSTOM_DATA_PATH, 'gym_data.xlsx');
} else if (isElectron) {
  // In Electron, we try to store the database in the User Data folder
  try {
    const { app } = await import('electron');
    const userData = app.getPath('userData');
    EXCEL_PATH = path.join(userData, 'gym_data.xlsx');
  } catch (e) {
    EXCEL_PATH = path.join(process.cwd(), 'gym_data.xlsx');
  }
} else {
  EXCEL_PATH = path.join(process.cwd(), 'gym_data.xlsx');
}

console.log('📂 Database Path:', EXCEL_PATH);

function syncToExcel() {
  try {
    const wb = xlsx.utils.book_new();

    const wsMembers = xlsx.utils.json_to_sheet(db.members);
    const wsPayments = xlsx.utils.json_to_sheet(db.payments);
    const wsAttendance = xlsx.utils.json_to_sheet(db.attendance);
    const wsWeight = xlsx.utils.json_to_sheet(db.weight_tracker);
    const wsClassTypes = xlsx.utils.json_to_sheet(db.class_types);
    const wsClassPart = xlsx.utils.json_to_sheet(db.class_participation);

    xlsx.utils.book_append_sheet(wb, wsMembers, 'Members');
    xlsx.utils.book_append_sheet(wb, wsPayments, 'Payments');
    xlsx.utils.book_append_sheet(wb, wsAttendance, 'Attendance');
    xlsx.utils.book_append_sheet(wb, wsWeight, 'Weight_Tracker');
    xlsx.utils.book_append_sheet(wb, wsClassTypes, 'Class_Types');
    xlsx.utils.book_append_sheet(wb, wsClassPart, 'Class_Participation');

    xlsx.writeFile(wb, EXCEL_PATH);
    console.log('✅ Spreadsheet synced: gym_data.xlsx');
  } catch (err) {
    console.error('❌ Failed to sync spreadsheet:', err);
  }
}

function loadFromExcel() {
  if (!fs.existsSync(EXCEL_PATH)) {
    console.log('ℹ️ No existing spreadsheet found. Starting fresh.');
    return;
  }

  try {
    const workbook = xlsx.readFile(EXCEL_PATH);
    console.log('📂 Found master spreadsheet. Restoring data...');

    const sheetMap: Record<string, keyof DBState> = {
      'Members': 'members',
      'Payments': 'payments',
      'Attendance': 'attendance',
      'Weight_Tracker': 'weight_tracker',
      'Class_Types': 'class_types',
      'Class_Participation': 'class_participation'
    };

    for (const [sheetName, key] of Object.entries(sheetMap)) {
      const sheet = workbook.Sheets[sheetName];
      if (sheet) {
        db[key] = xlsx.utils.sheet_to_json(sheet);
      }
    }
    console.log('🚀 Memory Database restoration complete.');
  } catch (err) {
    console.error('❌ Failed to restore from spreadsheet:', err);
  }
}

function generateUniqueId() {
  let id = '';
  let exists = true;
  while (exists) {
    id = Math.floor(10000000 + Math.random() * 90000000).toString();
    exists = db.members.some(m => m.id === id);
  }
  return id;
}

// Initial Load
loadFromExcel();

async function startServer() {
  const app = express();
  app.use(express.json());

  // API Routes
  app.get('/api/dashboard', (req, res) => {
    try {
      const now = new Date();
      
      // Cleanup expired daily members automatically
      const expiredCount = db.members.length;
      db.members = db.members.filter(m => {
        if (m.type === 'daily' && new Date(m.expiry) < now) {
          // Cascade delete
          db.attendance = db.attendance.filter(a => a.member_id !== m.id);
          db.weight_tracker = db.weight_tracker.filter(w => w.member_id !== m.id);
          return false;
        }
        return true;
      });
      
      if (db.members.length !== expiredCount) {
        syncToExcel();
      }

      const membersSorted = [...db.members].sort((a, b) => String(a.name).localeCompare(String(b.name)));
      
      const paymentsWithNames = [...db.payments].map(p => {
        const member = db.members.find(m => m.id === p.member_id);
        return { ...p, member_name: member ? member.name : 'Unknown' };
      }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 50);

      const fiveDaysFromNow = new Date();
      fiveDaysFromNow.setDate(fiveDaysFromNow.getDate() + 5);
      
      const expiringSoon = db.members.filter(m => {
        const exp = new Date(m.expiry);
        return exp <= fiveDaysFromNow && exp >= now;
      });

      const totalRevenue = db.payments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
      const transactionCount = db.payments.length;
      const monthlyRevenue = db.payments.filter(p => p.months >= 1).reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
      const dailyRevenue = totalRevenue - monthlyRevenue;

      res.json({ 
        members: membersSorted, 
        payments: paymentsWithNames, 
        expiringSoon, 
        stats: {
          totalRevenue,
          totalTransactions: transactionCount,
          monthlyRevenue,
          dailyRevenue
        }
      });
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  app.get('/api/tracker', (req, res) => {
    try {
      const logs = [...db.weight_tracker].map(w => {
        const member = db.members.find(m => m.id === w.member_id);
        return { ...w, member_name: member ? member.name : 'Unknown' };
      }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      res.json({ logs });
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  app.post('/api/tracker', (req, res) => {
    const { memberId, weight } = req.body;
    try {
      const newEntry = {
        id: Date.now().toString(),
        member_id: String(memberId),
        weight: Number(weight),
        date: new Date().toISOString()
      };
      db.weight_tracker.push(newEntry);
      syncToExcel();
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  app.delete('/api/tracker/:id', (req, res) => {
    const { id } = req.params;
    try {
      db.weight_tracker = db.weight_tracker.filter(w => String(w.id) !== String(id));
      syncToExcel();
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  app.delete('/api/members/:id', (req, res) => {
    const { id } = req.params;
    try {
      db.members = db.members.filter(m => m.id !== id);
      db.attendance = db.attendance.filter(a => a.member_id !== id);
      db.weight_tracker = db.weight_tracker.filter(w => w.member_id !== id);
      db.payments = db.payments.filter(p => p.member_id !== id);
      syncToExcel();
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  app.post('/api/members/:id/status', (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    try {
      const member = db.members.find(m => m.id === id);
      if (member) member.status = String(status);
      syncToExcel();
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  app.post('/api/register', (req, res) => {
    const { id, name, months, amount, type, classes, dob } = req.body;
    try {
      const expiryDate = new Date();
      const numMonths = Number(months) || 1;
      const numAmount = Number(amount) || 0;

      if (type === 'daily') {
        expiryDate.setHours(expiryDate.getHours() + (numMonths * 24));
      } else {
        expiryDate.setHours(expiryDate.getHours() + (numMonths * 30 * 24));
      }
      const expiryStr = expiryDate.toISOString();
      const finalId = id ? String(id) : generateUniqueId();

      db.members.push({
        id: finalId,
        name: String(name),
        expiry: expiryStr,
        type: String(type || 'monthly'),
        status: 'active',
        classes: classes || false,
        dob: dob || null,
        created_at: new Date().toISOString()
      });

      db.payments.push({
        id: Date.now().toString(),
        member_id: finalId,
        amount: numAmount,
        months: type === 'daily' ? (numMonths / 1000) : numMonths,
        expiry_date: expiryStr,
        date: new Date().toISOString()
      });

      syncToExcel();
      res.json({ success: true, memberId: finalId, expiryStr });
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  app.post('/api/renew', (req, res) => {
    const { memberId, months, amount, type } = req.body;
    try {
      const member = db.members.find(m => m.id === String(memberId));
      if (!member) throw new Error('Member not found');

      const currentExpiry = new Date(member.expiry);
      const now = new Date();
      const baseDate = currentExpiry > now ? currentExpiry : now;

      const newExpiry = new Date(baseDate);
      const numMonths = Number(months) || 1;
      const numAmount = Number(amount) || 0;

      if (type === 'daily') {
        newExpiry.setHours(newExpiry.getHours() + (numMonths * 24));
      } else {
        newExpiry.setHours(newExpiry.getHours() + (numMonths * 30 * 24));
      }
      const expiryStr = newExpiry.toISOString();

      member.expiry = expiryStr;
      member.type = String(type || 'monthly');

      db.payments.push({
        id: Date.now().toString(),
        member_id: String(memberId),
        amount: numAmount,
        months: type === 'daily' ? (numMonths / 1000) : numMonths,
        expiry_date: expiryStr,
        date: new Date().toISOString()
      });

      syncToExcel();
      res.json({ memberId, expiryStr });
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  app.post('/api/checkin', (req, res) => {
    const { memberId } = req.body;
    try {
      const member = db.members.find(m => m.id === String(memberId) || m.name.toLowerCase() === String(memberId).toLowerCase());
      if (!member) return res.status(404).json({ error: 'Member not found' });
      if (member.status === 'inactive') return res.status(403).json({ error: 'Member is marked as inactive' });
      
      const now = new Date().toISOString();
      if (member.expiry < now) return res.status(403).json({ error: 'Membership expired' });

      db.attendance.push({
        id: Date.now().toString(),
        member_id: member.id,
        timestamp: new Date().toISOString()
      });
      syncToExcel();
      res.json({ success: true, memberName: member.name });
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  app.get('/api/attendance', (req, res) => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const todayEntries = db.attendance.filter(a => a.timestamp.startsWith(today)).map(a => {
        const member = db.members.find(m => m.id === a.member_id);
        return { ...a, member_name: member ? member.name : 'Unknown' };
      }).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

      const hourCounts: Record<string, number> = {};
      db.attendance.forEach(a => {
        const hour = new Date(a.timestamp).getHours().toString().padStart(2, '0');
        hourCounts[hour] = (hourCounts[hour] || 0) + 1;
      });
      
      const hourlyStats = Object.entries(hourCounts).map(([hour, count]) => ({ hour, count })).sort((a, b) => a.hour.localeCompare(b.hour));

      res.json({ todayEntries, hourlyStats });
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  app.get('/api/classes', (req, res) => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const participation = db.class_participation.filter(p => p.timestamp.startsWith(today)).map(p => {
        const member = db.members.find(m => m.id === p.member_id);
        const classType = db.class_types.find(c => c.id === p.class_id);
        return { 
          ...p, 
          member_name: member ? member.name : 'Unknown',
          class_name: classType ? classType.name : 'Unknown'
        };
      }).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

      res.json({ types: db.class_types, participation });
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  app.post('/api/classes', (req, res) => {
    const { name } = req.body;
    try {
      const newClass = { id: Date.now().toString(), name: String(name) };
      db.class_types.push(newClass);
      syncToExcel();
      res.json(newClass);
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  app.delete('/api/classes/:id', (req, res) => {
    const { id } = req.params;
    try {
      db.class_types = db.class_types.filter(c => String(c.id) !== String(id));
      db.class_participation = db.class_participation.filter(p => String(p.class_id) !== String(id));
      syncToExcel();
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  app.post('/api/classes/attendance', (req, res) => {
    const { memberId, classId } = req.body;
    try {
      const member = db.members.find(m => m.id === String(memberId) || m.name.toLowerCase() === String(memberId).toLowerCase());
      if (!member) return res.status(404).json({ error: 'Member not found' });
      
      const classType = db.class_types.find(c => String(c.id) === String(classId));
      if (!classType) return res.status(404).json({ error: 'Class not found' });

      if (member.status === 'inactive') return res.status(403).json({ error: 'Member is inactive' });
      const now = new Date().toISOString();
      if (member.expiry < now) return res.status(403).json({ error: 'Membership expired' });

      const newRecord = {
        id: Date.now().toString(),
        member_id: member.id,
        class_id: classId,
        timestamp: now
      };
      db.class_participation.push(newRecord);
      syncToExcel();
      res.json({ success: true, memberName: member.name, className: classType.name });
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  app.get('/api/download/excel', (req, res) => {
    if (fs.existsSync(EXCEL_PATH)) {
      res.download(EXCEL_PATH, 'gym_database_backup.xlsx');
    } else {
      res.status(404).json({ error: 'Spreadsheet not found.' });
    }
  });

  app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist/index.html'));
    });
  }

  const PORT = 3000;
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://localhost:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('CRITICAL: Failed to start server:', err);
});
